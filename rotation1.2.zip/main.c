/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void printing(int arr[],int n)
{
    printf("after rotation: ");
    for(int i=0;i<n;i++)
    {
        printf("%d\t",arr[i]);
    }
}
void rotation(int arr[],int n)
{
    int d;
    printf("enter the d value");
    scanf("%d",&d);
    while(d!=0)
    {
        int temp = arr[0];
        for(int i=0;i<n;i++)
        {
            arr[i]=arr[i+1];
            
        }
        arr[n-1]=temp;
        d--;
    }
}
void intialize(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
}
int main()
{
    int n;
    printf("enter the size ");
    scanf("%d",&n);
    int arr[n];
    intialize(arr,n);
    rotation(arr,n);
    printing(arr,n);
    return 0;
}
