/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
void printing(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        printf("%d\t",arr[i]);
    }
}
void rotate(int arr[],int n)
{
    int temp[n];
    int k=0,d;
    printf("enter the d value");
    scanf("%d",&d);
    for(int i=d;i<n;i++)
    {
        temp[k]=arr[i];
        k++;
    }
    for(int j=0;j<d;j++)
    {
        temp[k]=arr[j];
        k++;
    }
    for(int i=0;i<n;i++)
    {
        arr[i]=temp[i];
    }
    
    
}
void intialize(int arr[],int n)
{
    printf("Enter the elments");
    
    for(int i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
}

int main()
{
    int n;
    printf("enter  the size ");
    scanf("%d",&n);
    int arr[n];
    intialize(arr,n);
    rotate(arr,n);
    printing(arr,n);

    return 0;
}
